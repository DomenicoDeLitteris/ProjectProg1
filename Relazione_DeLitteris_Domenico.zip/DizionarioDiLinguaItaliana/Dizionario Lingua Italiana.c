#include <stdio.h>
#include <string.h>

/*       DIZIONARIO LINGUA ITALIANA              */
int ricerca_binaria(char chiave[], char *parole[], int n);
void main()
{
     char chiave[10];
	 int n,indice,m,i,res=0;
	 char *parole[]={"Abeto","Acne","Addome","Alessio","Argilla","Bambino","Becco","Barba","Biennale","Bicromia","Capo","Cane","Canto","Carita'","Cavolo"};
	 char *parole2[]={"abeto","acne","addome","alessio","argilla","bambino","becco","barba","biennale","bicromia","capo","cane","canto","carita'","cavolo"};
	 char *vocab[]={"sostantivo maschile di abete","Malattia della pelle","Parte inferiore del tronco,tra torace e bacino","Nome proprio di persona","Tipo di roccia sedimentaria","Essere umano tra la nascita e l'inizio della fanciullezza","Prolungamento appuntito di un organo","Insieme dei peli che crescono su guance e mento degli uomini","Che ha durata di due anni","Procedimento di stampa a colori","Testa dell'essere umano o chi  e' a capo dirige e comanda ","Animele domestico molto comune","Emissione di suoni musicali per mezzo della voce umana","Aiuto concreto(offerta in denaro) che si da' a un bisognoso","Ortaggio di forma tondeggiante con grande foglie"};
	 char testo[20],nuovaparola[10];
	 printf("    Dizionario della lingua italiana\n");
	 printf("Inserisci la parola da cercare: ");
	 gets(chiave);
	 n=15;
	 indice=ricerca_binaria(chiave,parole,n);
	 if (indice<0)
	 {
		 indice=ricerca_binaria(chiave,parole2,n);
	 }
	 if(indice>=0)
	 {
                  printf("%s: %s\n",chiave,vocab[indice]);
     }
     else
                  printf("Chiave non trovata\n");

     do
	 {
	 printf("Inserisci nuova parola: ");
     gets(nuovaparola);
	 } while(strlen(nuovaparola)==10);
	 printf("Ecco la nuova parola :%s\n",nuovaparola);
	 printf("inserire il significato:");
	 scanf("%s",&nuovaparola);

}


int ricerca_binaria(char chiave[], char *parole[], int n)
{
    int mediano, primo=0, ultimo=n-1;
    while (primo<=ultimo)
    {
          mediano=(primo+ultimo)/2;
          if(strcmp(chiave,parole[mediano])==0)
             return mediano;
          else if(strcmp(chiave,parole[mediano])<0)
             ultimo=mediano-1;
          else
             primo=mediano+1;
    }
    return -1;
}
