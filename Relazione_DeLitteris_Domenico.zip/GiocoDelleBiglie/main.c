#include "Header.h"

/*Si vuole sviluppare un programma per la simulazione del gioco delle biglie.
Supponiamo di avere un giocatore che gioca su di un campo di dimensione 50 x50. Il
giocatore (rosso in figura) in ogni istante pu� lanciare in una delle 8 direzioni. Nel
campo da gioco esiste una sola buca, scelta in modo casuale all�inizio del gioco, che
permette di terminare il gioco ed � nota al giocatore.*/


int main() {
    int n=50; int m=50;//Variabili per il campo da gioco.
    int x=0; int y=0;
    int risultato;    //Variabile per il risultato del tentativo di tiro.
    int tentativi;    //Variabile che conta i tentativi fatti dal giocatore.
    int giocatori=0; int i;
    int risposta=0;   //Variabile per risposta a fine partita.

    char c[12];//Variabile per l'input del nome giocatoree il suo size.

    Agioc class[10];//Struct in cui viene allocato punteggio e nome giocatore per ogni nuova partita.


        //Inizializzazione del gioco.
        printf("\tGioco delle biglie!\n\nPremi Invio per visualizzare le regole.\n");
        getchar();
        printf("Queste sono le regole:\n[1]Puoi tirare in 4 direzioni.\n[2]Hai 50 tiri a disposizione.\n[3]Potresti finire in una buca trappola e purtroppo perderai.\n[4]Se finisci in altre buche trappola esse potrebbero lanciare la tua biglia ovunque!\nSe sei pronto premi Invio per iniziare!\n");


    do {
        tentativi=0;//Azzero variabile tentativi ad ogni partita.

        getchar();

        printf("\nNome giocatore:");//Richiedo nome giocatore.
        gets(c);                           //Prendo in input nome giocatore.
        strcpy(class[giocatori].nome_gioc,c);//Copio la stringa nome contenuta in "c" nella variabile nome_gioc della struct class.

        Campo campo[50][50]={prato};//Dichiaro tutte le posizioni del campo <"prato"/0>, cos� da poter fare una nuova generazione ad ogni partita.
        generazione(campo, n, m);   //Richiamo la function "generazione" e assegno le buche in maniera casuale

        printf("Ricorda: Occhio alle buche!\n");

        visualizzacampo(campo);//Richiamo function "visualizzacampo".Stampa il campo da gioco.

        //Scelta del lancio biglia
        do {
            printf("Dove vuoi lanciare la tua biglia?\nPremi->[1]=Nord\nPremi->[2]Est\nPremi->[3]Sud\nPremi->[4]Ovest\n");
            scanf("%d", &x);                             //Scelgo direzione in cui lanciare la biglia.
            printf("Di quante caselle vuoi avanzare?\n");
            scanf("%d", &y);                             //Scelgo di quante caselle avanzare.

            risultato = tentativo(campo, x, y);                 //Alloco risultato del tentativo nella variabile.

            tentativi++;                                        //Incremento variabile tentativo.

            if (risultato > 0) {//Se il risultato non consiste nella sconfitta o vincita, visualizzo di nuovo il campo da gioco con la nuova posizione.
                visualizzacampo(campo);
            }
        } while (risultato > 0 && tentativi < 50);//Se non � sconfitta o vittoria e i tentativi sono minori di 50, si effettua un nuovo tentativo.

        //Uscita dal ciclo, quindi vittoria o sconfitta.
        if(tentativi>=50){//Se la sconfitta � determinata dai tentativi.
            printf("\nMi dispiace hai finito i tentativi, non hai vinto!\n");
        }

        if(risultato==-1){//Se � sconfitta assegno il massimo dei tentativi al giocatore.
            class[giocatori].p=50;
        }
        else{//Altrimenti assegno i tentativi effettuati in caso di vittoria.
          class[giocatori].p=tentativi;}

        printf("\nVuoi continuare a giocare?\n[1]=SI\t[Qualsiasi altro numero]=NO\n");
        scanf("%d",&risposta);//Scelta se si vuole rigiocare oppure concludere il gioco.

        if(giocatori>=1){              //Se i giocatori sono pi� di uno, si effettua un ordinamento della classifica.
            ord_class(class,giocatori);}//Richiamo function per ordinare la classifica.Ordina dal punteggio pi� piccolo al pi� grande.

        printf("    Classifica\nNome\t   Punteggio\n\n");//Inizializzazione della classifica.

            for(i=0;i<=giocatori;i++){                                            //Stampo la classifica giocatori.
                printf("%-10s | %-10d\n",class[i].nome_gioc,class[i].p);}

        giocatori++;//Incremento variabile giocatore nel caso in cui la risposta sia rigiocare.

    } while (risposta==1);//Il ciclo si ripete, quindi nuova partita, nel caso in cui la risposta sia 1(SI).

    system("PAUSE");//Permette di mettere il programma in attesa di un input.
}
