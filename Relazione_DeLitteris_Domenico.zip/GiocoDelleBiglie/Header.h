


#include <stdio.h>
#include <math.h>
#include <string.h>
#include "stdlib.h"
#include "time.h"


typedef enum {prato,vincente,casuale,perdente,giocatore}Tipo;//Tipologia di buca.

typedef struct {//Struct per la costruzione del campo.
    Tipo  tipo;
}Campo;         //Essa sar� possibile utilizzarla con "Campo".

struct agioc {       //Struct per la costruzione della classifica.
    int p;            //Variabile punteggio/tentativi.
    char nome_gioc[10];//Variabile per nome giocatore.
};
typedef struct agioc Agioc;//La struct agioc, con questa funzione sar� ora possibile identificarla con "Agioc".

void generazione(Campo [][50] ,int , int );     //Function per la generazione del campo.

void visualizzacampo(Campo [][50]);              //Fuction per la visualizzazione del campo.

void max_val_pos(Campo [][50], int ,int *, int *);//Function per trovare posizione dellca cella vincente.

int tentativo(Campo [][50],int ,int );            //Function per tentativo di tiro e assegnazione delle nuove posizioni.

int scambio(Campo [][50],int ,int );              //Function per scambio posizione per le varie dinamiche possibili.

void ord_class(Agioc [],int );                   //Function di ordinamento per selezione di minimo, in ordine crescente.

int min_val_class(Agioc [], int );               //Function per trovare la posizione del valore minimo contenuto nell'array.

void scambiare_c( Agioc [], Agioc []);           //Function per scambiare le posizioni in classifica a seconda del punteggio.

