
#include "Header.h"

//Genero le celle che indicano vittoria/sconfitta/casuale/prato/giocatore.
void generazione(Campo griglia[][50],int m, int n){ //Passo come parametri l'array di struct e le sue dimensioni.
    int i;//variabile per ciclo for.
    int x,y;//variabili in cui allocare posizioni random di riga e colonna.

    srand(time(NULL));//Inizializzo il seme rand con la funzione time(NULL), in modo da avere ad ogni avvio del programma sequenze di numeri casuali diverse.

    //CELLE CASUALI.
    for (i=0; i<30; i++) {
                x= rand()%50;        //Assegno numero casuale della riga.
                y=rand()%50;          //Assegno numero casuale della colonna.
            griglia[x][y].tipo=casuale;//Assegno il tipo di cella alla struct.
    }

    //CELLE PERDENTI.
    for(i=0;i<10;i++) {
            x = rand() % 50;            //Assegno numero casuale della riga.
            y = rand() % 50;             //Assegno numero casuale della colonna.
            if (griglia[x][y].tipo == 0) {//Se la posizione � libera e non � stata assegnata gi� ad un altro tipo di cella,
                griglia[x][y].tipo = perdente;//diventa una cella perdente.
            }
            else                        //Altrimenti decremento la i, in modo da non perdere una possibile cella perdente.
                i--;
    }

    //CELLA VINCENTE.
    do {         //Avvio un ciclo do-while.
    x= rand()%50;//Assegno numero casuale della riga da 0 a 49.
    y=rand()%50;//Assegno numero casuale della colonna da 0 a 49.
    if(griglia[x][y].tipo==0){//Se la posizione � libera e non � stata assegnata gi� ad un altro tipo di cella,
        griglia[x][y].tipo=vincente;//diventa cella vincente.
    }
    } while (griglia[x][y].tipo!=vincente);//Il ciclo si ripete finch� non si verifica la condizione nell'if e quindi assegnata la cella vincente alle coordinate in questione.


    //CELLA GIOCATORE.
    do {//Avvio un ciclo do-while.
        x = rand() % 50;            //Assegno numero casuale della riga da 0 a 49.
        y = rand() % 50;             //Assegno numero casuale della colonna da 0 a 49.
        if (griglia[x][y].tipo == 0) {//Se la posizione � libera e non � stata assegnata gi� ad un altro tipo di cella,
            griglia[x][y].tipo = giocatore;//diventa cella giocatore.
        }
    } while (griglia[x][y].tipo!=giocatore);//Il ciclo si ripete finch� non si verifica la condizione nell'if e quindi assegnata la cella vincente alle coordinate in questione.

    //CELLE PRATO.
    for(i=0;i<n;i++){
        x= rand()%50;           //Assegno numero casuale della riga da 0 a 49.
        y= rand()%50;            //Assegno numero casuale della colonna da 0 a 49.
        if(griglia[x][y].tipo==0){//Se la posizione � libera e non � stata assegnata gi� ad un altro tipo di cella,
            griglia[x][y].tipo=prato;//diventa una cella prato.
        }
    }
}

void visualizzacampo(Campo griglia[][50]){ //Passo come parametro l'array di struct.
    int i,j;                               //Variabili per ciclo for.
    int pos1,pos2;                         //Variabili a cui i valori delle coordinate della cella vincente.
    pos1=0;                                //Inizializzo valore della variabile.
    pos2=0;                                //Inizializzo valore della variabile.

    max_val_pos(griglia,1,&pos1,&pos2);//Richiamo function per trovare posizione della cella vincente.In pos1 e pos2 saranno assegnate le coordinate.

    for (i = 0; i < 50; i++) {               //Ciclo for per incrementare posizione riga.
        for (j = 0; j < 50; j++) {           //Ciclo for per incrementare posizione colonna.
            if(griglia[i][j].tipo==giocatore){//Se ci troviamo nella coordinata della cella giocatore, controlliamo anche dove si trova la cella vincente,
                if(i<pos1)                    //quindi se la posizione della cella vincente si trova in basso rispetto al giocatore
                    printf("|v");     //il giocatore sara' rivolto verso il basso.
                else if(i>pos1)               //Se la posizione della cella vincente si trova in alto rispetto al giocatore
                printf("|^");         //il giocatore sara' rivolto verso l'alto.
                if(i==pos1){                 //Se la posizione della cella vincente si trova sulla stessa riga del giocatore
                    if(j<pos2)               //alla sua destra,
                        printf("|>"); // esso sara' rivolto verso destra,
                        else                 //altrimenti
                        printf("|<");}}//sara' rivolto verso sinistra.
            if(griglia[i][j].tipo==casuale){//Se ci troviamo nel caso di una cella casuale,
                printf("|_");}       //stampiamo una porzione di campo, essendo essa nascosta al giocatore.
            if(griglia[i][j].tipo==prato){//Se ci troviamo nel caso di una cella prato,
                printf("|_");     //stampiamo una porzione di campo.
            }
            if(griglia[i][j].tipo==vincente && i==pos1 && j==pos2){//Se ci troviamo nel caso di una cella vincente,
                printf("|O");                               //stampiamo "|0" in modo da renderla riconoscibile al giocatore.
            }
            if(griglia[i][j].tipo==perdente){//Se ci troviamo nel caso di una cella perdente,
                printf("|_");        //stampiamo una porzione di campo, essendo nascosta al giocatore.
            }
        }
        printf("\n");//Passo alla riga successiva.
    }
}

void max_val_pos(Campo v[][50], int n,int *pos1, int *pos2)//Passo come parametri della function l'array di struct,il numero (tipo di cella) da trovare e i due puntatori che prenderanno le due coordinate e le restituiranno una volta trovate.
{
    int i,j;
    *pos1= 0;//Ascissa
    *pos2= 0;//Ordinata
    for(i=0;i<50;i++) {
        for (j = 0; j < 50; j++) {
            if (v[i][j].tipo == n) {//Se corrisponde al numero(tipo) passato:
                *pos1 = i;          //Assegno il valore di i(riga).
                *pos2 = j;          //Assegno il valore di j(colonna).
            }
        }
    }
}

int tentativo(Campo v[][50],int x,int y) {//Passo come parametri l'array di struct, la direzione e di quante caselle voglio spostarmi.

    int pos1,pos2;//Variabili per coordinate giocatore.
    int nv1,nv2;  //Variabili che in ogni "case" assumeranno il nuovo valore che prender� la posizione giocatore.
    int cas1,cas2;//Variabili che utilizzeremo nel caso in cui il giocatore finisse in una cella casuale, quindi per assegnare una nuova posizione random.
    int casu;     //Variabile che utilizzeremo nel caso in cui la biglia finisse fuori dal bordo.
    pos1=0;
    pos2=0;
    max_val_pos(v,4,&pos1,&pos2);//Richiamo la function per trovare posizione giocatore, che verranno assegnate a pos1 e pos2.
    v[pos1][pos2].tipo=prato;       //La posizione precedente al tentativo del giocatore verr� resa di tipo 0 (prato).
    switch (x) {
        case 1://caso in cui si sceglie di spostarsi a Nord.
            nv1=pos1-y;      //La posizione della riga viene decrementata.
            nv2=pos2;         //La posizione della colonna rimane invariata.
            if(nv1<0){         //Se la biglia esce fuori dal bordo.
                casu= rand()%50;//Assegno valore casuale da 0 a 49 per la colonna.
                return scambio(v,0,casu);//Richiamo la function per poter spostare il giocatore sul bordo dove e' fuoriuscita la biglia e fare le opportune assegnazioni.
            }
            if(v[nv1][nv2].tipo==prato){  //Se la biglia finisce in una cella del campo di tipo prato
                v[nv1][nv2].tipo=giocatore;//essa diviene la nuova posizione del giocatore.
            }
            if(v[nv1][nv2].tipo==casuale){//Se la biglia finisce su una cella di tipo "casuale"
                cas1=rand()%50;           //randomizzo posizione della riga,
                cas2=rand()%50;            //randomizzo posizione della colonna.
                return scambio(v,cas1,cas2);// Richiamo function per controllare in che buca random finisce la biglia e fare le opportune assegnazioni.
            }
            if(v[nv1][nv2].tipo==vincente){           //Se la biglia finisce nella cella vincente
                printf("\nBravo hai vinto !!\n");//Stampo messaggio di vittoria
                return 0;                             //E ritorno 0.
            }
            if(v[nv1][nv2].tipo==perdente){                            //Se la biglia finisce in una cella perdente
                printf("\nMi dispiace la tua biglia e' andata persa, non hai vinto!\n");//Stampo messaggio di sconfitta
                return -1;                                              //E ritorno -1.
            }
            break;
        case 2:
            nv1=pos1;            //La posizione della riga rimane invariata.
            nv2=pos2+y;             //La posizione della colonna viene incrementata.
            if(nv2>49){                 //Se la biglia esce fuori dal bordo.
                casu=rand()%50;            //Assegno valore casuale da 0 a 49 per la riga.
                return scambio(v,casu,49);//Richiamo la function per poter spostare il giocatore sul bordo dove e' fuoriuscita la biglia e fare le opportune assegnazioni.
            }
            if(v[nv1][nv2].tipo==prato){  //Se la biglia finisce in una cella del campo di tipo prato
                v[nv1][nv2].tipo=giocatore;//essa diviene la nuova posizione del giocatore.
            }
            if(v[nv1][nv2].tipo==casuale){//Se la biglia finisce su una cella di tipo "casuale"
                cas1=rand()%50;            //randomizzo posizione della riga,
                cas2=rand()%50;            //randomizzo posizione della colonna.
                return scambio(v,cas1,cas2);//Richiamo function per controllare in che buca random finisce la biglia e fare le opportune assegnazioni.
            }
            if(v[nv1][nv2].tipo==vincente){           //Se la biglia finisce nella cella vincente
                printf("\nBravo hai vinto !!\n");//Stampo messaggio di vittoria
                return 0;                            //E ritorno 0.
            }
            if(v[nv1][nv2].tipo==perdente){                          //Se la biglia finisce in una cella perdente
                printf("\nMi dispiace la tua biglia e' andata persa, non hai vinto!\n");//Stampo messaggio di sconfitta
                return -1;                                                  //E ritorno -1.
            }
            break;

        case 3:
            nv1=pos1+y;                   //La posizione della riga viene incrementata.
            nv2=pos2;                      //La posizione della colonna rimane invariata.
            if(nv1>49){                     //Se la biglia esce fuori dal bordo.
                casu=rand()%50;              //Assegno valore casuale da 0 a 49 per la colonna.
                return scambio(v,49,casu);//Richiamo la function per poter spostare il giocatore sul bordo dove e' fuoriuscita la biglia e fare le opportune assegnazioni.
            }
            if(v[nv1][nv2].tipo==prato){  //Se la biglia finisce in una cella del campo di tipo prato
                v[nv1][nv2].tipo=giocatore;//essa diviene la nuova posizione del giocatore.
            }
            if(v[nv1][nv2].tipo==casuale){//Se la biglia finisce su una cella di tipo "casuale"
                cas1=rand()%50;           //randomizzo posizione della riga,
                cas2=rand()%50;            //randomizzo posizione della colonna.
                return scambio(v,cas1,cas2);// Richiamo function per controllare in che buca random finisce la biglia e fare le opportune assegnazioni.
            }
            if(v[nv1][nv2].tipo==vincente){           //Se la biglia finisce nella cella vincente
                printf("\nBravo hai vinto !!\n");//Stampo messaggio di vittoria
                return 0;                              //E ritorno 0.
            }
            if(v[nv1][nv2].tipo==perdente){                                 //Se la biglia finisce in una cella perdente
                printf("\nMi dispiace la tua biglia e' andata persa, non hai vinto!\n");//Stampo messaggio di sconfitta
                return -1;                                                       //E ritorno -1.
            }
            break;

        case 4:
            nv1=pos1;                     //La posizione della riga rimane invariata.
            nv2=pos2-y;                    //La posizione della colonna viene decrementata.
            if(nv2<0){                      //Se la biglia esce fuori dal bordo.
                casu=rand()%50;              //Assegno valore casuale da 0 a 49 per la riga.
                return scambio(v,casu,0);//Richiamo la function per poter spostare il giocatore sul bordo dove e' fuoriuscita la biglia e fare le opportune assegnazioni.
            }
            if(v[nv1][nv2].tipo==prato){  //Se la biglia finisce in una cella del campo di tipo prato
                v[nv1][nv2].tipo=giocatore;//essa diviene la nuova posizione del giocatore.
            }
            if(v[nv1][nv2].tipo==casuale){//Se la biglia finisce su una cella di tipo "casuale"
                cas1=rand()%50;           //randomizzo posizione della riga,
                cas2=rand()%50;           //randomizzo posizione della colonna.
                return scambio(v,cas1,cas2);// Richiamo function per controllare in che buca random finisce la biglia e fare le opportune assegnazioni.
            }
            if(v[nv1][nv2].tipo==vincente){          //Se la biglia finisce nella cella vincente
                printf("\nBravo hai vinto !!\n");//Stampo messaggio di vittoria
                return 0;                              //E ritorno 0.
            }
            if(v[nv1][nv2].tipo==perdente){                                 //Se la biglia finisce in una cella perdente
                printf("\nMi dispiace la tua biglia e' andata persa, non hai vinto!\n");//Stampo messaggio di sconfitta
                return -1;                                                             //E ritorno -1.
            }
            break;
    }
    return 1;
}

int scambio(Campo v[][50],int nv1,int casu){//Passo come parametri la struct e le due nuove coordinate.

    int cas1; int cas2;                   //Variabili per posizione random.
    if(v[nv1][casu].tipo==prato){          //Se la biglia finisce in una cella del campo di tipo prato
       return v[nv1][casu].tipo=giocatore; //Ritorno la nuova posizione del giocatore.
    }
    if(v[nv1][casu].tipo==casuale){      //Se la biglia finisce in una cella del campo di tipo casuale
        cas1=rand()%50;                  //randomizzo posizione della riga,
        cas2=rand()%50;                  //randomizzo posizione della colonna.
        return scambio(v,cas1,cas2);     //Richiamo function scambio per eseguire controllo nuova posizione e fare assegnazione.
    }
    if(v[nv1][casu].tipo==vincente){           //Se la biglia finisce in una cella del campo di tipo vincente
        printf("\nBravo hai vinto !!\n"); //Stampo messaggio di vittoria.
        return 0;                               //Ritorno 0.
    }
    if(v[nv1][casu].tipo==perdente){                                                 //Se la biglia finisce in una cella del campo di tipo perdente
        printf("\nMi dispiace la tua biglia e' andata persa, non hai vinto!\n");//Stampo messaggio di sconfitta.
        return -1;                                                                    //Ritorno -1.
    }
    return 0;
}

void ord_class(Agioc a[],int n)//Passo come parametri l'array di struct per la classifica e la sua dimensione.
{
    int i;//Variabile per ciclo for e per indice array.
    for(i=0; i<=n-1; i++)
    {
        scambiare_c(&a[i], &a[min_val_class(a+i,n-i)+i]);//Richiamo la function "min_val_class" per trovare indice del punteggio con minor tentativi.
    }                                                              //Richiamo anche la function "scambiare_c" per eseguire lo scambio di posizioni.
}

int min_val_class(Agioc v[], int n)//Passo come parametri l'array di struct per la classifica e la sua dimensione meno la porzione i.
{
    int i,pos;
    int min;
    min= v[0].p;//Assegno come valore minimo la prima posizione dell'array.
    pos= 0;     //Assegno come indice la prima posizione dell'array.
    for(i=1;i<=n;i++)
        if(min>v[i].p)//Se la i-esimo valore dell'array e' piu' piccolo del valore di min:
        {
            min=v[i].p;//Assegno l'i-esimo valore a min.
            pos=i;     //L'indice dell'i-esimo valore assegnato viene copiato in pos.
        }
    return pos; //Ritorno pos, posizione trovata.
}

void scambiare_c( Agioc s1[], Agioc s2[]) //Passo come parametri i due array di struct annessi di indice con i quali eseguire lo scambio
{

    int temp_p;              //dichiaro una variabile int temporanea.
    char temp_nome[10];       //dichiaro una variabile char array temporanea.

    temp_p=s1->p;                   //Copio il valore di "p" contenuto nella struct s1 in temp_p.
    strcpy(temp_nome,s1->nome_gioc);//Copio la stringa "nome_gioc" contenuta nella struct s1 in temp_nome.

    s1->p=s2->p;                      //Copio il valore di "p" contenuto nella struct s2 in s1.
    strcpy(s1->nome_gioc,s2->nome_gioc);//Copio la stringa "nome_gioc" contenuta nella struct s2 in "nome_gioc" di s1.

    s2->p=temp_p;                       //Copio il valore di "p" contenuto nella variabile temporanea temp_p in "p" di s2.
    strcpy(s2->nome_gioc,temp_nome);     //Copio la stringa contenuta in "temp_nome" in "nome_gioc" di s2.

}
